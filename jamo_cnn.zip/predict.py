"""시험용 예측: python predict.py --input test_images/ --output predict_03.csv"""
import argparse
import csv
from pathlib import Path

import torch
from model import FOLDERS, JamoCNN, prepare_image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not args.input.is_dir():
        parser.error(f"입력 폴더를 찾을 수 없습니다: {args.input}")
    if args.output.suffix.lower() != ".csv":
        parser.error("출력 파일의 확장자는 .csv여야 합니다.")
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    paths = sorted(p for p in args.input.iterdir() if p.is_file() and p.suffix.lower() in exts)
    if not paths:
        parser.error("입력 폴더에 사진이 없습니다.")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = Path(__file__).resolve().parent / "results" / "best.pt"
    saved = torch.load(checkpoint, map_location=device, weights_only=True)
    if saved["classes"] != FOLDERS:
        raise ValueError("저장 모델의 클래스 순서를 확인하세요.")
    model = JamoCNN().to(device)
    model.load_state_dict(saved["weights"])
    model.eval()
    rows = []
    with torch.inference_mode():
        for start in range(0, len(paths), 16):
            batch = paths[start:start + 16]
            images = torch.stack([prepare_image(path, saved["size"]) for path in batch])
            predictions = model(images.to(device)).argmax(1).tolist()
            rows.extend((path.name, pred) for path, pred in zip(batch, predictions))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.output.with_suffix(".csv.tmp")
    with tmp.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["filename", "pred"])
        writer.writerows(rows)
    tmp.replace(args.output)
    print(f"예측 {len(rows)}장 저장: {args.output}")


if __name__ == "__main__":
    main()
