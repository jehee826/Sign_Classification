"""Spyder F5 또는 python train.py 로 실행."""
import csv
import math
import os
import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from torch import nn
from torch.utils.data import Dataset, DataLoader

from model import FOLDERS, SIGNS, JamoCNN, prepare_image

# %% 1. 팀 설정
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "team_data"
OUTPUT = ROOT / "results"
SIZE = 192
BATCH = 16
EPOCHS = 30
LR = 0.001
SEED = 42
VAL_FRACTION = 0.2


def seed_everything():
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


# %% 2. 클래스별 파일 목록과 검증 분할
def split_files():
    rng = random.Random(SEED)
    train_rows, val_rows = [], []
    for label, folder in enumerate(FOLDERS):
        directory = DATA_DIR / folder
        paths = sorted(p for p in directory.glob("*")
                       if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg"})
        if len(paths) < 2:
            raise ValueError(f"{directory}: 분할하려면 JPG가 2장 이상 필요합니다. 제출 기준은 팀원별 자음당 30장 이상입니다.")
        rng.shuffle(paths)
        count = min(len(paths) - 1, max(1, round(len(paths) * VAL_FRACTION)))
        val_rows.extend((p, label) for p in paths[:count])
        train_rows.extend((p, label) for p in paths[count:])
    return train_rows, val_rows


class HandPhotos(Dataset):
    def __init__(self, rows, augment=False):
        self.rows = rows
        self.augment = augment

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        path, label = self.rows[index]
        return prepare_image(path, SIZE, self.augment), label


# %% 3. 학습 또는 검증 한 회 수행
def run_epoch(model, loader, device, loss_fn, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    correct = 0
    matrix = np.zeros((len(SIGNS), len(SIGNS)), dtype=int)
    with torch.set_grad_enabled(training):
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            if training:
                optimizer.zero_grad()
            scores = model(images)
            loss = loss_fn(scores, labels)
            if training:
                loss.backward()
                optimizer.step()
            predictions = scores.argmax(1)
            total_loss += loss.item() * len(labels)
            correct += (predictions == labels).sum().item()
            if not training:
                np.add.at(matrix, (labels.cpu().numpy(), predictions.cpu().numpy()), 1)
    n = len(loader.dataset)
    return total_loss / n, 100 * correct / n, matrix


def save_matrix(matrix, path):
    cell = 40
    img = Image.new("RGB", (650, 690), "white")
    draw = ImageDraw.Draw(img)
    draw.text((20, 12), "Validation confusion matrix | rows: actual, columns: predicted", fill="black")
    peak = max(1, int(matrix.max()))
    for i, name in enumerate(FOLDERS):
        draw.text((66 + i * cell, 45), name, fill="black")
        draw.text((22, 72 + i * cell), name, fill="black")
        for j, count in enumerate(matrix[i]):
            x, y = 60 + j * cell, 60 + i * cell
            shade = int(125 * count / peak)
            draw.rectangle((x, y, x + cell - 1, y + cell - 1),
                           fill=(248 - shade, 250 - shade, 255), outline="gray")
            draw.text((x + 4, y + 12), str(count), fill="black")
    pairs = matrix + matrix.T
    upper = np.triu(pairs, k=1)
    if upper.max() > 0:
        for i, j in np.argwhere(upper == upper.max()):
            print(f"최다 혼동 쌍 {SIGNS[i]} ↔ {SIGNS[j]}: {matrix[i,j]} + {matrix[j,i]}장")
    else:
        print("검증 오분류 0장")
    img.save(path)


# %% 4. 증강 OFF/ON 비교와 최종 모델 선택
def main():
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.use_deterministic_algorithms(True, warn_only=True)
    train_rows, val_rows = split_files()
    OUTPUT.mkdir(exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"장치 {device} | 학습 {len(train_rows)}장 | 검증 {len(val_rows)}장")
    best_overall = math.inf
    chosen = None
    with (OUTPUT / "train_log.csv").open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow(["augmentation", "epoch", "train_loss", "train_acc_pct",
                         "val_loss", "val_acc_pct"])
        for augment in (False, True):
            seed_everything()
            mode = "ON" if augment else "OFF"
            generator = torch.Generator().manual_seed(SEED)
            train_loader = DataLoader(HandPhotos(train_rows, augment), batch_size=BATCH,
                                      shuffle=True, generator=generator)
            val_loader = DataLoader(HandPhotos(val_rows), batch_size=BATCH)
            model = JamoCNN().to(device)
            optimizer = torch.optim.Adam(model.parameters(), lr=LR)
            loss_fn = nn.CrossEntropyLoss()
            best_run_loss = math.inf
            for epoch in range(1, EPOCHS + 1):
                tl, ta, _ = run_epoch(model, train_loader, device, loss_fn, optimizer)
                vl, va, matrix = run_epoch(model, val_loader, device, loss_fn)
                if not math.isfinite(vl):
                    raise ValueError("검증 손실이 유한하지 않습니다. 입력과 학습률을 확인하세요.")
                writer.writerow([mode, epoch, tl, ta, vl, va])
                file.flush()
                print(f"{mode} {epoch}/{EPOCHS} | 학습 {tl:.4f}, {ta:.1f}% | 검증 {vl:.4f}, {va:.1f}%")
                if vl < best_run_loss:
                    best_run_loss, best_epoch, best_acc = vl, epoch, va
                if vl < best_overall:
                    best_overall = vl
                    chosen = (mode, epoch, va, matrix.copy())
                    tmp = OUTPUT / "best.pt.tmp"
                    torch.save({"weights": model.state_dict(), "size": SIZE,
                                "classes": FOLDERS, "augmentation": mode, "epoch": epoch}, tmp)
                    tmp.replace(OUTPUT / "best.pt")
            print(f"증강 {mode} 최저 검증 손실 시점: {best_epoch}회, 검증 정확도 {best_acc:.1f}%")
    mode, epoch, acc, matrix = chosen
    print(f"최종 선택: 증강 {mode}, {epoch}회, 검증 정확도 {acc:.1f}%")
    save_matrix(matrix, OUTPUT / "confusion_matrix.png")


if __name__ == "__main__":
    main()
