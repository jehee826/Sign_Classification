"""14개 자음과 공통 전처리, 기본 CNN."""
import random

import numpy as np
from PIL import Image, ImageEnhance, ImageOps
import torch
from torch import nn

SIGNS = tuple("ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅋㅌㅍㅎ")
FOLDERS = [f"c{i:02d}" for i in range(len(SIGNS))]


def prepare_image(path, size, augment=False):
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert("RGB")
    image = ImageOps.pad(image, (size, size), method=Image.Resampling.BILINEAR)
    if augment:
        image = image.rotate(random.uniform(-7, 7), resample=Image.Resampling.BILINEAR)
        image = ImageEnhance.Brightness(image).enhance(random.uniform(0.85, 1.15))
    pixels = np.array(image, dtype=np.float32) / 255.0
    return torch.from_numpy(pixels).permute(2, 0, 1).contiguous()


class JamoCNN(nn.Module):
    def __init__(self):
        super().__init__()
        layers = []
        channels = [3, 16, 32, 64]
        for inputs, outputs in zip(channels, channels[1:]):
            layers.extend([
                nn.Conv2d(inputs, outputs, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.MaxPool2d(2),
            ])
        self.features = nn.Sequential(*layers, nn.AdaptiveAvgPool2d((4, 4)))
        self.fc = nn.Linear(64 * 4 * 4, len(SIGNS))

    def forward(self, images):
        features = self.features(images)
        return self.fc(torch.flatten(features, 1))
